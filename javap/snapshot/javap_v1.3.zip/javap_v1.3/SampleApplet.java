//last updated:<2015/09/09/Wed 10:42:31 from:YUSUKE-PC>
// SampleApplet.javaでappletviewerを実行出来るようにする700 650
// <applet code="SampleApplet.class" width="700" height="650"></applet>

import java.applet.Applet;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Random;

public class SampleApplet extends Applet implements Runnable, KeyListener {
	// error check ================================
	// SampleApplet.error_check+;
	public static int error_check = 0;

	// ゲームの設定 ================================
	public static final int bullet_max = 300; // 同時に発射できるユニットの弾数
	public static final int group_max = 10;	// 同時に表示できる敵のグループ数
	public static final int e_bullet_max = 300;	// 同時に表示できる敵の弾
	public static final int invincible_time = 80; // ユニットが死んだ時の無敵時間
	public static int frame = 0;				  // 全体の同期をとる
	public static final int enemy_max = 100; // 同時に表示できる敵の数

	// その他の設定 ===============================
	public static final int sidebar_width = 200; // sidebar の幅
	public static final int star_max = 35; // 画面に表示できる星の数
	public static final int star_i = 100;  //
 	public static Graphics gv;			   // buffer用
	public static FontMetrics fm; // 文字の位置を調節する
	public static boolean game_flag = false, exit = false;
	public static int field_width, field_height; // フィールドの幅と高さ
	public static Dimension applet_size; // 画面の縦と横の大きさ
	public static int score = 0;		// スコア
	private Image offImage;		// buffer用イメージ
	public int strWidth, strHeight;
	public static int bullet_wait = 0; // ユニットの弾の発射間隔を数える
	public String message;		// タイトル画面の表示する文字
	public int select = 1;		// タイトル画面のモードセレクト
	public static int dif = 0;							// 難易度
	public int gradually = 0, R = 200, G = 0, B = 0;	// タイトル画面の背景の色
	static boolean my_shot_flag = false;
	static Star star[] = new Star[star_max];
	static Unit my_unit = new Unit();
	static Bullet my_bullet[] = new Bullet[bullet_max];
	static Boss boss = new Boss();
	static Group group[] = new Group[group_max];
	static Enemy enemy[] = new Enemy[enemy_max];
	static Ebullet e_bullet[] = new Ebullet[e_bullet_max];
	static Random rand = new Random();	// 乱数用
	Thread gameThread = null;	// スレッドを入れる変数

	// ===========================================

	public void init() {		// アプレット実行時に自動実行される
		applet_size = getSize();
		field_width = applet_size.width - sidebar_width;
		field_height = applet_size.height;
		for (int i = 0; i < bullet_max; i++) { my_bullet[i] = new Bullet();	}
		for (int i = 0; i < enemy_max; i++) { enemy[i] = new Enemy(); }
		for (int i = 0; i < group_max; i++) { group[i] = new Group(); }
		for (int i = 0; i < e_bullet_max; i++) { e_bullet[i] = new Ebullet(); }
		for (int i = 0; i < star_max; i++) { star[i] = new Star(); }
		for (int i = 0; i < star_max; i++) {
			star[i].y = (i/5)*star_i;
			star[i].x = (i%5)*(field_width/5) + rand.nextInt(100);
		}
		// ダブルバッファリング
		offImage = createImage(applet_size.width, applet_size.height);
		gv = offImage.getGraphics();
		// スレッド関連
		gameThread = new Thread(this);
		gameThread.start();
		// キー入力を待つ
		addKeyListener(this);
	}

	public void paint(Graphics g) { // 描画全般を行う関数 (最後に書いたものが一番上に表示される)
		if (game_flag) {
			background();
			my_unit.update();
			draw_bullet();
			appear();
			for (int i = 0; i < group_max; i++) { group[i].update(); }
			for (int i = 0; i < enemy_max; i++) { enemy[i].update(); }
			for (int i = 0; i < e_bullet_max; i++) { e_bullet[i].update(); }
			if (Boss.active) { Boss.update(); }
			sidebar();
		} else {
			title();
		}
		g.drawImage(offImage, 0, 0, this); // bufferの内容を描画
		requestFocusInWindow();	// 自動でappletviewerにfocusさせる

	}

	// group(type, property, num, wait, dx, dy, x, y, behavior, b_property)
	// type 0:右  1:下  2:右下 [enemy]
	// behavior 0:真下  1:右斜め下  2:真下(縦長) [bullet]
	public void appear() {	// 敵を出現させる関数
		switch (frame % 200) {
		case 50:
			// group[available("g")].group(1,3, 1,0, 80,0, 200,0, 2,1);
			group[available("g")].group(1,3, 6,0, 80,0, 60,0, 0,6);
			group[available("g")].group(2,4, 5,60, 0,20, 0,0, 1,-3);
			// 	break;
			//  case 100:
			//  group[available("g")].group(0,3, 5,70, 0,0, 0,250, 1,3);
			// 	group[available("g")].group(1,3, 5,0, 80,0, 100,0, 0,6);
			//  break;
			//  case 150:
			// 	group[available("g")].group(2,5, 6,50, 0,20, 0,0, 1,3);
			// 	group[available("g")].group(0,-3, 5,50, 0,0, 0,250, 1,-3);
			// 	break;
			//  case 190:
			// 	group[available("g")].group(0,-3, 5,50, 0,0, 0,250, 1,3);
			// 	group[available("g")].group(2,3, 5,40, 0,20, 0,0, 1,3);
			break;
		}
		if (frame == 50) { Boss.active = true;	} // Bossを出現させる
		frame++;
	}

	public void draw_bullet() {	// ユニットの弾を表示する
		for (int i = 0; i < bullet_max; i++) {
			if (my_bullet[i].active) { my_bullet[i].update(); }
		}
		if (my_shot_flag) {
			if (bullet_wait >= Bullet.bullet_wait_min && !my_unit.invincible) {
				for (int i = 1; i <= Unit.power*2-1; i++) {
					my_bullet[available("b")].shot_bullet(i);
				}
			}
		}
		bullet_wait++;
	}

	public int available(String s) {
		switch (s) {
		case "g":
			for (int i = 0; i < group_max; i++) {
				if (!group[i].active) { return i; }
			}
		case "b":
			for (int i = 0; i < bullet_max; i++) {
				if (!my_bullet[i].active) { return i; }
			}
		}
		return -1;
	}

	public void title() {
		if (gradually == 0) { G++; if (G == 200) { gradually++; } }
		else if (gradually == 1) { R--; if (R == 0) { gradually++; } }
		else if (gradually == 2) { B++; if (B == 200) { gradually++; } }
		else if (gradually == 3) { G--; if (G == 0) { gradually++; } }
		else if (gradually == 4) { R++; if (R == 200) { gradually++; } }
		else { B--; if (B == 0) { gradually = 0;} }
		gv.setColor (new Color(R, G, B));
		gv.fillRect (0, 0, applet_size.width, applet_size.height); // 背景
		gv.setColor (new Color(B, R, G));
		gv.setFont(new Font("ＭＳ ゴシック", Font.BOLD, 70));
		message = "タイトル募集中";
		fm = gv.getFontMetrics();
		strWidth = fm.stringWidth(message);
		gv.drawString(message,(applet_size.width - strWidth)/2, 150);
		gv.setFont(new Font("ＭＳ ゴシック", Font.BOLD, 60));
		gv.setColor (new Color(G, B, R));
		if (select == 1) {	message = "Easy"; }
		else if (select == 2) {	message = "Normal"; }
		else if (select == 3) { message = "Hard"; }
		strWidth = fm.stringWidth(message);
		gv.drawString(message, (applet_size.width - strWidth)/2, 400);
	}

	public void background() {		   // 背景を描画する関数
		gv.setColor(new Color(5, 5, 5)); // RGB
		gv.fillRect(0, 0, field_width, field_height);
		SampleApplet.gv.setColor(new Color(255, 255, 0)); // 星の色
		SampleApplet.gv.setFont(new Font("ＭＳ ゴシック", Font.BOLD, 10));
		for (int i = 0; i < star_max; i++) { star[i].update(); }
	}

	public void sidebar () { // サイドバーを描画する関数
		gv.setFont(new Font("ＭＳ ゴシック", Font.BOLD, 18));
		gv.setColor(new Color(200, 0, 20));
		gv.fillRect(field_width, 0,	applet_size.width, applet_size.height);
		gv.setColor(new Color(255, 255, 255));
		gv.fillRect(field_width, 0,	applet_size.width, (int)(applet_size.height*((boss.life_m - boss.life)/boss.life_m)));
		gv.setColor(new Color(0, 0, 0));
		gv.fillRect(field_width, 0, 2, field_height);
		gv.drawString("Score :"+score+"",field_width+10 ,30);
		gv.drawString("Player:"+my_unit.life+"",field_width+10 ,50);
		gv.drawString("Power :"+Unit.power+"",field_width+10 ,90);
		// 以下エラー確認用
		gv.drawString("FRAME :"+frame+"",field_width+10 ,70);
		gv.drawString("Check :"+Unit.power_cnt+"",field_width+10 ,110); // error check
	}

	public void run() {			// スレッドに実行される関数
		while (!exit) {
			repaint();
			if (game_flag) { score++; }
			try { Thread.sleep(30); }
			catch (InterruptedException e) {}
		}

	}

	public void update(Graphics g) { // 軌跡を表示するために再定義
		paint(g);
	}

	public void reset() {
		frame = 0; score = 0;
		my_shot_flag = false;
		Unit.reset();
		Bullet.reset();
		Group.reset();
		Enemy.reset();
		Ebullet.reset();
		Boss.reset();
	}

	public void keyPressed(KeyEvent e) { // キーを押した時用の関数
		switch (e.getKeyCode()) {
		case KeyEvent.VK_ESCAPE: game_flag = false; reset();  break;
		case KeyEvent.VK_SPACE:
			if (my_shot_flag) { my_shot_flag = false; }
			else { if (my_unit.alive) { my_shot_flag = true; } }
			break;
		case KeyEvent.VK_RIGHT:	my_unit.vx += my_unit.vx < 1 ? 1 : 0; break;
		case KeyEvent.VK_LEFT:	my_unit.vx -= my_unit.vx > -1 ? 1 : 0; break;
		case KeyEvent.VK_UP:
			if (game_flag) { my_unit.vy -= my_unit.vy > -1 ? 1 : 0; }
			else { select++; if (select == 4) { select = 1; } } break;
		case KeyEvent.VK_DOWN:
			if (game_flag) { my_unit.vy += my_unit.vy < 1 ? 1 : 0; }
			else { select--; if (select == 0) { select = 3; } }break;
		case KeyEvent.VK_SHIFT:	my_unit.slow = true; break;
		case KeyEvent.VK_ENTER:
			if (1 <= select && select <= 3) { reset(); dif = select; game_flag = true; }
			break;
		}
	}

	public void keyReleased(KeyEvent e) { // キーを離した時用の関数
		switch (e.getKeyCode()) {
		case KeyEvent.VK_RIGHT: my_unit.vx -= 1; break;
		case KeyEvent.VK_LEFT:  my_unit.vx += 1; break;
		case KeyEvent.VK_UP:    my_unit.vy += 1; break;
		case KeyEvent.VK_DOWN:  my_unit.vy -= 1; break;
		case KeyEvent.VK_SHIFT: my_unit.slow = false; break;
		}
	}

	public void keyTyped(KeyEvent e) {
		// キーを入力した時用の関数（中身は空）
	}
}
// class ================================
class Unit {
	public static int life_m = 100;			// 初期体力
	public static int power_m = 5; // ユニットのパワーの最大値
	public static int vx_m = 12, vy_m = 12; // ユニットの速度
	public static int vx_s = 5, vy_s = 5;	 // 低速移動時の速度
	public static int vx = 0, vy = 0;		 // ユニットの進む向き(-1, 0, 1)
	public static int width = 25, height = 25, life;
	public static int x, y;
	public static int p_r = 4;								 // ユニットの中心の点の大きさ
	public static boolean alive, invincible, slow;
	public static int power = 1, power_cnt = 0; // パワーと敵を倒した数を数える
	public static int invincible_cnt = 0;	   // 無敵時間をカウント(ms)
	public Color color =new Color(200, 100, 150); // ユニットの色
	public Color i_color = new Color(200, 100, 150, 99); // 無敵時の色
	public Color p_color = new Color(255, 255, 255); // 当たり判定の点の色
	Unit () { // はじめに一回だけ実行される
		reset();
	}

	public void update() {
		if (life == 0) { alive = false; SampleApplet.my_shot_flag = false; }
		if (alive) {
			if (invincible) { invincible(); }
			if ( power*10 <= power_cnt ) {
				if (power <= power_m - 1) {
					power++;
					power_cnt = 0;
				}
			}
			paint();
			move();
		}
	}

	public void paint() {
		if (invincible) { SampleApplet.gv.setColor(i_color); }
		else { SampleApplet.gv.setColor(color); }
		SampleApplet.gv.fillRect(x - width/2, y - height/2, width, height);
		SampleApplet.gv.setColor(p_color);
		SampleApplet.gv.fillOval(x - p_r/2, y - p_r/2 , p_r, p_r);
	}

	public void move() {
		// ユニットに低速移動をさせるかどうか
		if (!slow) { x += vx_m * vx; y += vy_m * vy; }
		else { x += vx_s * vx; y += vy_s * vy; }
		// ユニットが画面の端ギリギリまで行けるように調整する
		if (x < 0) {x = 0;}
		if (SampleApplet.field_width < x) {
			x = SampleApplet.field_width;
		}
		if (y < 0) {y = 0;}
		if (SampleApplet.field_height < y) {
			y = SampleApplet.field_height;
		}
	}

	public void invincible () {
		invincible_cnt--;
		if (invincible_cnt == 0) { invincible = false; }
	}

	static void unit_lost (int invincible_time) { // ユニットがやられた時の関数
		life--;
		invincible_cnt += invincible_time;
		invincible = true;
		x = SampleApplet.field_width/2;
		y = SampleApplet.field_height - height;
		Bullet.reset();
		Group.reset();
		Enemy.reset();
		Ebullet.reset();
		power_cnt = 0;
		if (1 < power) { power--; }
	}

	public static void reset () {
		life = life_m;
		alive = true;
		power = 1;
		x = SampleApplet.field_width/2;
		y = SampleApplet.field_height;
		vx = 0; vy = 0;
		invincible_cnt = 0;
		invincible = false;
		slow = false;
		width = 25; height = 25;
		power_cnt = 0;
		SampleApplet.bullet_wait = 0;
	}

}

class Bullet {
	public static final int bullet_wait_min = 2; // ユニットの弾の発射間隔 2
	public final int vxf = 0, vyf = 24, r = 8; // 0, 24, 8
	public int dvx = 1;
	public int vx = 0, vy = 0;
	public int x = 0, y = 0;
	public boolean active = false;
	public boolean bullet_check; // ユニットか敵の弾かを判定する (ユニット:true,  敵:false)
	public Color color = new Color(250, 0, 0);

	public void shot_bullet(int power) {	// ユニットの弾を発射する関数(SampleApplet から呼ばれる)
		active = true;
		if (power % 2 == 1) { vx = vxf + (power/2)*dvx; }
		if (power % 2 == 0) { vx = (-1) * (vxf + (power/2)*dvx); }
		vy = vyf;
		x = SampleApplet.my_unit.x;
		y = SampleApplet.my_unit.y - SampleApplet.my_unit.height/2;
		SampleApplet.bullet_wait = 0;
	}

	public void update() {
		SampleApplet.gv.setColor(color);
		// ユニットの発射されている弾を動かして描画する
		if (active) {
			x += vx;
			y -= vy;
			SampleApplet.gv.fillOval(x - r/2, y - r/2, r, r);
			active = Utils.check_f(x, y, r, r);
			if (!Utils.check_b(x, y)) { // 弾が敵にあたっていたら
				active = false;
				SampleApplet.score += 100;
			}
		}
	}

	public static void reset () {
		for (int i = 0; i < SampleApplet.bullet_max; i++) {
			SampleApplet.my_bullet[i].active = false;
		}
	}

}

class Boss {
	public static double life, life_m = 1000;
	public static double x, y;
	public static double vx, vy;
	public static int width, height;
	public static boolean active;        // ボスが生きているかどうか
	public static int shot_wait;		 // 弾の発射間隔を数える
	public static int frame;			 // ボスの同期をとる

	Boss () {
		reset ();
	}

	public static void update() {
		pattern();
		move();
		check();
		draw();
		frame++;				// ボスの同期をとる
	}

	static void pattern () {
		if (frame == 0) { vx = 0; vy = 3; }
		if (frame == 20) { vx = 0; vy = 0; }
	}

	static void move () {
		x += vx; y += vy;
	}

	static void check () {
		Utils.check_f((int)x, (int)y, width, height);
		Utils.check_u("r", (int)x, (int)y, width, height);
		if (life <= 0) { active = false; }
	}

	static void draw () {
		SampleApplet.gv.setColor(new Color(0, 255, 255));
		SampleApplet.gv.fillRect((int)x, (int)y, width, height);
	}

	static void reset () {
		active = false;
		x = SampleApplet.field_width/2 - width/2;
		y = (-1)*height;
		vx = 0; vy = 0;
		width = 150; height = 50;
		life = life_m;
		frame = 0;
	}

}

class Group {					// 敵のグループを管理する
	public int x, dx, y, dy;
	public int type, property, num, wait;
	public boolean active = false;
	public boolean group_check = true; // wait が 0 の時すべての敵を同時に表示
	public int wait_cnt = 0;
	public int b_property = 1;
	public int behavior = 0;

	public void group(int _type, int _property, int _num, int _wait,
					  int _dx, int _dy, int _x, int _y, int _behavior, int _b_property) {
		active = true;
		group_check = true;
		if (_wait == 0) { group_check = false; }
		type = _type; property = _property; num = _num; wait = _wait;
		wait_cnt = _wait;
		dx = _dx; dy = _dy;
		x = _x; y = _y;
		behavior = _behavior;
		b_property = _b_property;
	}

	public void update () {
		if (active) {
			if (group_check) {
				if (wait == wait_cnt) {
					SampleApplet.enemy[available()]
						.type(type, property, x, y, behavior, b_property);
					num--;
					if (num == 0) { active = false; }
					x += dx; y += dy;
					wait_cnt = 0;
				}
				wait_cnt++;
			} else { // wait が 0 の時用
				for (int i = 0; i < num; i++) {
					SampleApplet.enemy[available()]
						.type(type, property, x + i*dx, y + i*dy, behavior, b_property);
				}
				group_check = true;
				active = false;
			}
		}

	}

	public int available() {
		for (int i = 0; i < SampleApplet.enemy_max; i++) {
			if (!SampleApplet.enemy[i].active){ return i; }
		}
		return -1;
	}

	public static void reset () {
		for (int i = 0; i < SampleApplet.group_max; i++) {
			SampleApplet.group[i].active = false;
		}
	}

}

class Enemy {
	public int width, height, life, property;
	public int x, y, vx, vy;
	public int num, dx, dy, wait;
	public int behavior = 0;
	public String shape = "r";
	public Color color;
	public boolean active = false;
	public int  shot_wait_min = 0;		// 敵の発射する間隔を決める
	public int shot_wait = 0;			// 敵の発射する間隔をカウントする
	public int b_property = 1;			// 弾のプロパティ

	// 敵の種類を決める
	public void type(int _type, int _pro, int _x, int _y, int _beh, int _b_pro) {
		active = true;
		switch (_type) {
		case 0:					// 右に動く
			set_e(_pro,_x,_y,20,20, 6,1,0,new Color(255, 0, 0), 70,_beh,_b_pro);
			break;
		case 1:					// 下に動く
			set_e(_pro,_x,_y,20,20, 20,0,1,new Color(0, 255, 0), 100,_beh,_b_pro);
			break;
		case 2:					// 右下に動く
			set_e(_pro,_x,_y,20,20, 4,1,1,new Color(0, 0, 255), 80,_beh,_b_pro);
			break;
		}
	}

	public void set_e (int _property, int _x, int _y, int _width, int _height,
					   int _life, int _vx, int _vy, Color _color,
					   int _shot_wait_min, int _behavior, int _b_property) {
		property = _property;
		if (0 < property) {x = _x - _width;}
		else { x = SampleApplet.field_width + _x; }
		y = _y - _height;
		width = _width; height = _height;
		life = _life;
		vx = _property * _vx;
		vy = _vy * _property;
		if (vy < 0) { vy *= -1; }
		color = _color;
		shot_wait_min = _shot_wait_min / SampleApplet.dif;
		shot_wait = shot_wait_min;
		behavior = _behavior;
		b_property = _b_property;
	}

	public void update() {		// 出現している敵の動作
		if (active) {
			move();
			check();
			draw();
			attack();
		}
	}

	public void move() {
		x += vx;
		y += vy;
	}

	public void check() {		// 敵のダメージ判定と生死
		active = Utils.check_f(x, y, width, height); // 敵が画面内にいるかどうか
		if ( life <= 0){ active = false; Unit.power_cnt++; return; } // 体力が無くなっている敵がいたら
		if (!Utils.check_u("r" , x, y, width, height)) { // ユニットと敵の接触判定
			if (!SampleApplet.my_unit.invincible) { // ユニットが無敵でない時だけ
				Unit.unit_lost(SampleApplet.invincible_time);
			}
		}
	}

	public void draw() {
		SampleApplet.gv.setColor(color);
		SampleApplet.gv.fillRect(x, y, width, height);
	}

	public void attack() {
		if (shot_wait_min <= shot_wait) {
			SampleApplet.e_bullet[available()]
				.behavior(behavior, b_property , x, y, width, height);
			shot_wait = 0;
		}
		shot_wait++;
	}

	public int available() {
		for (int i = 0; i < SampleApplet.e_bullet_max; i++) {
			if (!SampleApplet.e_bullet[i].active) { return i; }
		}
		return -1;
	}

	public static void reset () {
		for (int i = 0; i < SampleApplet.enemy_max; i++) {
			SampleApplet.enemy[i].active = false;
		}
	}

}

// アクティブなエネミーがタイプを指定してそのタイプの弾を発射する
class Ebullet {
	public int x, y;		// 弾のx,y座標
	public int r_x, r_y;
	public int vx, vy;
	public Color color;
	public String shape;
	public boolean active = false;
	public int b_property = 1;

	// 敵の攻撃の種類を決める
	public void behavior(int behavior, int _b_pro, int _x, int _y, int width, int height) {
		x = _x + width/2 - r_x/2;
		y = _y + height;
		switch (behavior) {
		case 0:					// 真下に動く弾
			set_b(_b_pro, 0, 1, 15, 15, new Color(255, 255, 255), "c"); break;
		case 1:					// 右斜下に動く弾
			set_b(_b_pro, 1, 3, 10, 10, new Color(255, 255, 255), "c"); break;
		case 2:					// 真下に動く縦長の弾
			set_b(_b_pro, 0, 1, 5, 20, new Color(255, 255, 255), "c"); break;
		}
	}

	public void set_b (int b_property, int _vx, int _vy, int _r_x, int _r_y,
					   Color _color, String _shape) {
		vx = _vx * b_property;
		vy =_vy * b_property;
		if (vy < 0) { vy *= -1; }
		r_x = _r_x; r_y = _r_y;
		color = _color;
		shape = _shape;
		active = true;
	}

	public void update() {
		if (active) {
			x += vx;
			y += vy;
			active = Utils.check_f(x, y, r_x, r_y);
			if (!Utils.check_u(shape, x, y, r_x, r_y)) { // ユニットと敵の弾が当たったら
				if (!SampleApplet.my_unit.invincible) {	 // ユニットが無敵でない時
					active = false;
					Unit.unit_lost(SampleApplet.invincible_time);
				}
			}
			SampleApplet.gv.setColor(color);
			SampleApplet.gv.fillOval(x, y, r_x, r_y);
		}
	}

	public static void reset () {
		for (int i = 0; i < SampleApplet.e_bullet_max; i++) {
			SampleApplet.e_bullet[i].active = false;
		}
	}

}

class Star {
	int x = 0, y = 0;
	int star_vf = 5;		// 背景の星が流れる速度

	public void update() {
		SampleApplet.gv.drawString("*", x, y);
		if (y >= SampleApplet.field_height+star_vf) { y = -10; }
		y += star_vf;
	}

}

class Utils {
	// 画面から出たかを判定する
	static boolean check_f(int x, int y, int width, int height) {
		if (x  < (-1 * width) || SampleApplet.field_width < x){
			return false;
		}
		if (y  < (-1 * height) || SampleApplet.field_height < y) {
			return false;
		}
		return true;			// 画面内にいれば true を返す
	}

	// ユニットとの当たり判定を行う (shape で判定するものの形を渡す)
	static boolean check_u(String shape, int x, int y, int width, int height) {
		int r, c_x, c_y, a, b;
		switch (shape) {
		case "r":
			if (x <= SampleApplet.my_unit.x
				&& SampleApplet.my_unit.x <= x + width
				&& y <= SampleApplet.my_unit.y
				&& SampleApplet.my_unit.y <= y + height) {
				return false;
			}
			break;
		case "c":
			c_x = SampleApplet.my_unit.x - (x + width/2);
			c_y = SampleApplet.my_unit.y - (y + height/2);
			if (width == height) { // 円なら
				r = (width/2);
				if (c_x*c_x + c_y*c_y  <= r*r) { return false; }
			} else {			// 楕円なら
				a = width/2;
				b = height/2;
				if ((c_x*c_x)*(b*b) + (c_y*c_y)*(a*a) <= a*a*b*b) { return false; }
			}
			break;
		}
		return true; // 当たっていなければ true を返す
	}

	// ユニットの弾との当たり判定を行う
	static boolean check_b (int x, int y) { // 弾のx,y
		for (int i = 0; i < SampleApplet.enemy_max; i++) {
			if (SampleApplet.enemy[i].active
				&& SampleApplet.enemy[i].x <= x
				&& x <= SampleApplet.enemy[i].x + SampleApplet.enemy[i].width
				&& SampleApplet.enemy[i].y <= y
				&& y <= SampleApplet.enemy[i].y + SampleApplet.enemy[i].height) {
				SampleApplet.enemy[i].life--;
				return false;
			}
		}
		if (Boss.active
			&& SampleApplet.boss.x <= x
			&& x <= SampleApplet.boss.x + SampleApplet.boss.width
			&& SampleApplet.boss.y <= y
			&& y <= SampleApplet.boss.y + SampleApplet.boss.height) {
			SampleApplet.boss.life--;
			return false;
		}
		return true; // 当たっていなければ true を返す
	}
}
