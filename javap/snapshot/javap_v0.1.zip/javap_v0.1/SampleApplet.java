//last updated:<2015/09/16/Wed 11:40:30 from:YUSUKE-PC>

// SampleApplet.javaでappletviewerを実行出来るようにする700 650
// <applet code="SampleApplet.class" width="700" height="650"></applet>

import java.applet.Applet;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class SampleApplet extends Applet implements Runnable, KeyListener {
	// error check ================================
	// SampleApplet.error_check+;
	public static int error_check = 0;

	// ゲームの設定 ================================
	public static final int bullets_max = 20;    // 同時に発射できるユニットの弾数 20
	public static final int enemys_max = 50;	 // 同時に表示できる敵の数
	public static final int groupe_max = 5;		 // 同時に表示できる敵のグループ数
	public static final int enemys_bullet_max = 200; // 同時に表示できる敵の弾
	public static final int invincible_time = 70;	 // ユニットが死んだ時の無敵時間
	public static int frame = 0;				 // 全体の同期をとる

	// その他の設定 ===============================
	public static final int sidebar_width = 200; // sidebar の幅
	public static final	Font font = new Font("Arial", Font.PLAIN, 18);
	public static int field_width;
	public static int field_height;
	public static Graphics gv;	// buffer用
	public static Dimension applet_size; // 画面の縦と横の大きさ
	public static long score = 0;		// スコア
	public static int bullet_wait = 0;	// ユニットの弾の発射間隔を数える
	private Image offImage;		// buffer用イメージ
	static boolean my_shot_flag = false;
	static Unit my_unit;
	static Bullet my_bullets[] = new Bullet[bullets_max];
	static Enemy enemy[] = new Enemy[enemys_max];
	static Groupe enemy_groupe[] = new Groupe[groupe_max];
	static EnemysBullet enemy_bullet[] = new EnemysBullet[enemys_bullet_max];
	Thread gameThread = null;	// スレッドを入れる変数

	// ===========================================

	public void init() {		// アプレット実行時に自動実行される
		applet_size = getSize();
		setFont(font);			 // フォントの設定
		field_width = applet_size.width - sidebar_width;
		field_height = applet_size.height;
		my_unit = new Unit();
		for (int i = 0; i < bullets_max; i++) {
			my_bullets[i] = new Bullet();
		}
		for (int i = 0; i < enemys_max; i++) {
			enemy[i] = new Enemy();
		}
		for (int i = 0; i < groupe_max; i++) {
			enemy_groupe[i] = new Groupe();
		}
		for (int i = 0; i < enemys_bullet_max; i++) {
			enemy_bullet[i] = new EnemysBullet();
		}
		// ダブルバッファリング
		offImage = createImage(applet_size.width, applet_size.height);
		gv = offImage.getGraphics();
		// スレッド関連
		gameThread = new Thread(this);
		gameThread.start();
		// キー入力を待つ
		addKeyListener(this);
	}

	public void paint(Graphics g) { // 描画全般を行う関数(最後に書いたものが一番上に表示される)
		draw_background();
		my_unit.update();
		// gv.setColor(Color.black);
		// gv.drawLine(250, 0, 250, 700);
		appear();
		draw_enemy();
		draw_bullet();
		for (int i = 0; i < enemys_bullet_max; i++) { // 実験
			if (enemy_bullet[i].active) { enemy_bullet[i].move(); }
		}
		draw_sidebar();
		g.drawImage(offImage, 0, 0, this); // bufferの内容を描画
		requestFocusInWindow();	// 自動でappletviewerにfocusさせる

	}

	//	groupe(type, property, num, wait, dx, dy, x, y)
	//  enemy_type(type, property, x, y) property != 0
	public void appear() {	// 敵を出現させる関数
		switch (frame % 200) {
		case 0:
			enemy_groupe[available("g")].groupe(3, -1, 7, 30, 0, 30, 0, 0);
			break;
		case 50:
		    enemy_groupe[available("g")].groupe(1, 1, 10, 0, 50, 0, 0, 0);
			break;
		case 100:
			enemy_groupe[available("g")].groupe(0, 1, 10, 20, 0, 0, 0, 250);
			break;
		case 150:
			enemy_groupe[available("g")].groupe(2, 1, 8, 20, 0, 20, 0, 0);
			break;
		}
	}

	public void draw_enemy() {
		for (int i = 0; i < groupe_max; i++) {
			if (enemy_groupe[i].active) { enemy_groupe[i].update(); continue;}
		}
		for (int j = 0; j < enemys_max; j++) {
			if (enemy[j].active) { enemy[j].check(); }
			if (enemy[j].active) { enemy[j].update();}
		}
	}

	public void draw_bullet() {	// ユニットと敵の弾を表示する
		for (int i = 0; i < bullets_max; i++) {
			if (my_bullets[i].active) {
				my_bullets[i].update();
			} else {
				my_bullets[i].shot_bullet();
			}
		}
		if (my_shot_flag) { bullet_wait++; }
	}

	public void draw_background() {		   // 背景を描画する関数
		gv.setColor(new Color(0, 250, 0)); // RGB
		gv.fillRect(0, 0, field_width, field_height);
	}

	public void draw_sidebar () { // サイドバーを描画する関数
		gv.setColor(new Color(200, 0, 20));
		gv.fillRect(field_width, 0,	applet_size.height, applet_size.height);
		gv.setColor(new Color(0, 0, 0));
		gv.drawString("Score  :"+score+"",field_width ,30);
		gv.drawString("Player :"+my_unit.life+"",field_width ,50);
		// 以下エラー確認用
		gv.drawString("FRAME  :"+frame+"",field_width ,70);
		error_check = 0;
		for (int i = 0; i < enemys_bullet_max; i++ ) {
			if (enemy_bullet[i].active) { error_check++; }
		}
		gv.drawString("check  :"+error_check+"",field_width ,110); // error check
		gv.drawString("my_unit.active  :"+my_unit.alive+"",field_width ,300);
	}

	public static int available(String s) {
		switch (s) {
		case "e":
			for (int i = 0; i < enemys_max; i++) {
				if (!enemy[i].active){ return i; }
			}
		case "g":
			for (int i = 0; i < groupe_max; i++) {
				if (!enemy_groupe[i].active) { return i; }
			}
		case "b":
			for (int i = 0; i < enemys_bullet_max; i++) {
				if (!enemy_bullet[i].active) { return i; }
			}
		}
		return -1;
	}

	public void run() {			// スレッドに実行される関数
		while (true) {
			repaint();
			frame++;
			score++;
			try { Thread.sleep(30); }
			catch (InterruptedException e) {}
		}
	}

	public void update(Graphics g) { // 軌跡を表示するために再定義
		paint(g);
	}

	public void keyPressed(KeyEvent e) { // キーを押した時用の関数
		switch (e.getKeyCode()) {
		case KeyEvent.VK_SPACE:
			if (my_shot_flag) { my_shot_flag = false; }
			else { if (my_unit.alive) { my_shot_flag = true; } }
			break;
		case KeyEvent.VK_Z:
			if (my_unit.slow) { my_unit.slow = false; }
			else { my_unit.slow = true; }
			break;
		case KeyEvent.VK_RIGHT:	my_unit.vx += my_unit.vx < 1 ? 1 : 0; break;
		case KeyEvent.VK_LEFT:	my_unit.vx -= my_unit.vx > -1 ? 1 : 0; break;
		case KeyEvent.VK_UP:	my_unit.vy -= my_unit.vy > -1 ? 1 : 0; break;
		case KeyEvent.VK_DOWN:	my_unit.vy += my_unit.vy < 1 ? 1 : 0; break;
		}
	}

	public void keyReleased(KeyEvent e) { // キーを離した時用の関数
		switch (e.getKeyCode()) {
		case KeyEvent.VK_RIGHT: my_unit.vx -= 1; break;
		case KeyEvent.VK_LEFT:  my_unit.vx += 1; break;
		case KeyEvent.VK_UP:    my_unit.vy += 1; break;
		case KeyEvent.VK_DOWN:  my_unit.vy -= 1; break;
		}
	}

	public void keyTyped(KeyEvent e) {
		// キーを入力した時用の関数（中身は空）
	}
}
// class ================================
class Unit {
	public int vx_m = 12, vy_m = 12; // ユニットの速度
	public int vx_s = 5, vy_s = 5;	 // 低速移動時の速度
	public int vx = 0, vy = 0;		 // ユニットの進む向き(-1, 0, 1)
	public int width = 25, height = 25, life = 5;
	public int x, y;
	public int p_r = 4;								 // ユニットの中心の点の大きさ
	public boolean alive, invincible, slow;
	public int invincible_cnt = 0;	   // 無敵時間をカウント(ms)
	public Color color =new Color(100, 100, 250); // ユニットの色
	public Color p_color = new Color(255, 255, 255); // 当たり判定の点の色
	public Color i_color = new Color(100, 100, 250, 50); // 無敵時の色
	Unit () { // はじめに一回だけ実行される
		alive = true;
		invincible = false;
		slow = false;
		x = SampleApplet.field_width/2;
		y = SampleApplet.field_height;
	}

	public void paint() {
		if (invincible) { SampleApplet.gv.setColor(i_color); }
		else { SampleApplet.gv.setColor(color); }
		SampleApplet.gv.fillRect(x - width/2, y - height/2, width, height);
		SampleApplet.gv.setColor(p_color);
		SampleApplet.gv.fillOval(x - p_r/2, y - p_r/2 , p_r, p_r);
	}

	public void move() {
		// ユニットに低速移動をさせるかどうか
		if (!slow) { x += vx_m * vx; y += vy_m * vy; }
		else { x += vx_s * vx; y += vy_s * vy; }
		// ユニットが画面の端ギリギリまで行けるように調整する
		if (x < 0) {x = 0;}
		if (SampleApplet.field_width < x) {
			x = SampleApplet.field_width;
		}
		if (y < 0) {y = 0;}
		if (SampleApplet.field_height < y) {
			y = SampleApplet.field_height;
		}
	}

	public void invincible () {
		invincible_cnt--;
		if (invincible_cnt == 0) { invincible = false; }
	}

	public void update() {
		if (life == 0) { alive = false; SampleApplet.my_shot_flag = false; }
		if (alive) {
			if (invincible) { invincible(); }
			paint();
			move();
		}
	}
}

class Bullet {
	public final int vxf = 0, vyf = 24, r = 8; // 0, 24, 8
	public static final int bullet_wait_min = 2; // ユニットの弾の発射間隔 2
	public int x = 0, y = 0;
	public boolean active = false;
	public boolean bullet_check; // ユニットか敵の弾かを判定する (ユニット:true,  敵:false)
	public Color color = new Color(250, 0, 0);
	public void update() {
		SampleApplet.gv.setColor(color);
		// ユニットの発射されている弾を動かして描画する
		if (active) {
			x += vxf;
			y -= vyf;
			SampleApplet.gv.fillOval(x - r/2, y - r/2, r, r);
			active = Utils.check_f(x, y, r, r);
		}
	}

	public void shot_bullet() {	// ユニットの弾を発射する関数
		if (SampleApplet.bullet_wait == bullet_wait_min) {
			if (SampleApplet.my_shot_flag) {
				active = true;
				x = SampleApplet.my_unit.x;
				y = SampleApplet.my_unit.y - SampleApplet.my_unit.height/2;
				SampleApplet.bullet_wait = 0;
			}
		}
	}
}


class Enemy {
	public int width, height, life, property;
	public int x, y, vx, vy;
	public int num, dx, dy, wait;
	public int behavior = 0;
	public String shape = "r";
	public Color color;
	public boolean active = false;
	public int type;			// 敵のタイプを決める
	public int  shot_wait_min = 0;		// 敵の発射する間隔を決める
	public int shot_wait = 0;			// 敵の発射する間隔をカウントする

	// 敵の種類を決める
	public void enemy_type(int _type, int _property, int _x, int _y) {
		type = _type;
		active = true;
		switch (type) {
		case 0:
			set_e(_property, _x, _y, 30, 30, 1, 5, 0, new Color(150, 50, 150), 0, 20);
			break;
		case 1:
			set_e(_property, _x, _y, 30, 30, 1, 0, 5, new Color(0, 0, 0), 0, 15);
			break;
		case 2:
			set_e(_property, _x, _y, 30, 30, 1, 5, 3, new Color(250, 250, 250), 0, 25);
			break;
		case 3:
			set_e(_property, _x, _y, 30, 30, 1, 5, 3, new Color(0, 0, 250), 0, 30);
			break;
		}
	}

	public void set_e (int _property, int _x, int _y, int _width, int _height,
					   int _life, int _vx, int _vy, Color _color,
					   int _behavior, int _shot_wait_min) {
		life = _life; property = _property;
		width = _width; height = _height;
		if (0 < property) {x = _x - _width;}
		else { x = SampleApplet.field_width - _x; }
		y = _y - _height;
		vx = _property * _vx; vy = _vy;
		color = _color;
		shot_wait_min = _shot_wait_min;
		behavior = _behavior;
	}

	public void update() {		// 出現している敵の動作
		x += vx;
		y += vy;
		SampleApplet.gv.setColor(color);
		SampleApplet.gv.fillRect(x, y, width, height);
		// 敵が攻撃する
		if (shot_wait_min == shot_wait) {
			SampleApplet.enemy_bullet[SampleApplet.available("b")]
				.behavior(behavior, x, y, width, height);
			shot_wait = 0;
		}
		shot_wait++;
	}

	public void check() {		// 敵のダメージ判定と生死
		active = Utils.check_f(x, y, width, height);

		// ユニットの発射した弾と敵
		for (int i = 0; i < SampleApplet.bullets_max; i++) {
			if (SampleApplet.my_bullets[i].active) {
				if (x <= SampleApplet.my_bullets[i].x
					&& SampleApplet.my_bullets[i].x <= x + width) {
					if (y <= SampleApplet.my_bullets[i].y
						&& SampleApplet.my_bullets[i].y <= y + height){
						SampleApplet.my_bullets[i].active = false;
						life--;
						SampleApplet.score += 100; // 敵にダメージを与えたら score を増やす
					}
				}
			}
			// 体力が無くなっている敵がいたら
			if ( life <= 0){ active = false; return; }
		}

		// ユニットと敵の接触判定
		if (!Utils.check_u(shape , x, y, width, height)) {
			if (!SampleApplet.my_unit.invincible) { // ユニットが無敵でない時だけ
				Utils.unit_lost(SampleApplet.invincible_time);
			}
		}
	}
}

class Groupe {					// 敵のグループを管理する
	public int x, dx, y, dy;
	public int type, property, num, wait;
	public boolean active = false;
	public boolean groupe_check = true; // wait が 0 の時すべての敵を同時に表示
	public int enemy_wait_cnt = 0;

	public void groupe(int _type, int _property, int _num, int _wait,
					   int _dx, int _dy, int _x, int _y) {
		active = true;
		groupe_check = true;
		if (_wait == 0) { groupe_check = false; }
		type = _type; property = _property; num = _num; wait = _wait;
		dx = _dx; dy = _dy;
		x = _x; y = _y;
	}

	public void update () {
		if (groupe_check) {
			if (wait == enemy_wait_cnt) {
				SampleApplet.enemy[SampleApplet.available("e")]
					.enemy_type(type, property, x, y);
				num--;
				if (num == 0) { active = false; }
				x += dx; y += dy;
				enemy_wait_cnt = 0;
			}
			enemy_wait_cnt++;
		} else { // wait が 0 の時用
			for (int i = 0; i < num; i++) {
				SampleApplet.enemy[SampleApplet.available("e")]
					.enemy_type(type, property, x + i*dx, y + i*dy);
			}
			groupe_check = true;
			active = false;
		}
	}
}

// アクティブなエネミーがタイプを指定してそのタイプの弾を発射する
class EnemysBullet {
	public int x, y;		// 弾のx,y座標
	public int r_x, r_y;
	public int vx, vy;
	public Color color;
	public String shape;
	public boolean active = false;

	// 敵の攻撃の種類を決める
	public void behavior(int behavior, int _x, int _y, int width, int height) {
		switch (behavior) {
		case 0:
			set_b(1, 0, 10, 15, 15, new Color(0, 0, 250), "c");
			break;
		case 1:
			set_b(1, 2, 5, 10, 10, new Color(100, 100, 0), "c");
		}
		x = _x + width/2 - r_x/2;
		y = _y + height;
	}

	public void set_b (int property, int _vx, int _vy, int _r_x, int _r_y,
					   Color _color, String _shape) {
		vx = _vx * property;
		vy =_vy;
		r_x = _r_x; r_y = _r_y;
		color = _color;
		shape = _shape;
		active = true;
	}

	public void move() {
		x += vx;
		y += vy;
		active = Utils.check_f(x, y, r_x, r_y);
		if (!Utils.check_u(shape, x, y, r_x, r_y)) { // ユニットと敵の弾が当たったら
			if (!SampleApplet.my_unit.invincible) {	 // ユニットが無敵でない時
			active = false;
			Utils.unit_lost(SampleApplet.invincible_time);
			}
		}
		SampleApplet.gv.setColor(color);
		SampleApplet.gv.fillOval(x, y, r_x, r_y);
	}
}

class Utils {
	// ユニットとの当たり判定を行う (shape で判定するものの形を渡す)
	static boolean check_u(String shape, int x, int y, int width, int height) {
		int r, c_x, c_y;
		switch (shape) {
		case "r":
			if (x <= SampleApplet.my_unit.x
				&& SampleApplet.my_unit.x <= x + width
				&& y <= SampleApplet.my_unit.y
				&& SampleApplet.my_unit.y <= y + height) {
				return false;
			}
			break;
		case "c":
			if (width == height) { // 円なら
				r = (width/2);
				c_x = SampleApplet.my_unit.x - (x + width/2);
				c_y = SampleApplet.my_unit.y - (y + height/2);
				if (r*r >= c_x*c_x + c_y*c_y) { return false; }
			} else {			// 楕円なら

			}
			break;
		}
		return true; // 当たっていなければ true を返す
	}

	// 画面から出たかを判定する
	static boolean check_f(int x, int y, int width, int height) {
		if (x  < (-1 * width) || SampleApplet.field_width < x){
			return false;
		}
		if (y  < (-1 * height) || SampleApplet.field_height < y) {
			return false;
		}
		return true;			// 画面内にいれば true を返す
	}

	static void unit_lost (int invincible_time) {
		SampleApplet.my_unit.life--;
		SampleApplet.my_unit.invincible_cnt += invincible_time;
		SampleApplet.my_unit.invincible = true;
		SampleApplet.my_unit.x = SampleApplet.field_width/2;
		SampleApplet.my_unit.y = SampleApplet.field_height - SampleApplet.my_unit.height;
	}
}
